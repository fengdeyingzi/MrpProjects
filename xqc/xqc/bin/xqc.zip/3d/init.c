#include <mrc_base.h>
#include <3d.h>
#include <3d/game.c>
int init(void)
{
	on_start();
    return 0;
}

int event(int type, int p1, int p2)
{
    if(KY_DOWN == type)
    {
		on_keydown(p1);
        switch(p1)
        {
        case _SRIGHT:
            exit();
            break;
        case _1:
            break;
        }
    }

    return 0;
}

int pause(void)
{
    return 0;
}

int resume(void)
{
    return 0;
}
